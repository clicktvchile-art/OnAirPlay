/** OnAirPlay activation API for Google Apps Script + Google Sheets.
 * Deploy as Web app, execute as owner, access according to your security policy.
 * Sheet columns: device_id | status | first_seen | last_seen | model | notes
 */
const SHEET_ID = '1GpTo9J9MUJSR8aMOJ33vNC40DMDVsIoS1RZ8FtO0CDc';
const SHEET_NAME = 'Devices';
function sheet_() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) { sh = ss.insertSheet(SHEET_NAME); sh.appendRow(['device_id','status','first_seen','last_seen','model','notes']); }
  return sh;
}
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function doGet(e) {
  const action = (e.parameter.action || 'check').toLowerCase();
  const id = String(e.parameter.id || '').trim();
  if (action !== 'check' || !id) return json_({authorized:false, error:'missing_action_or_id'});
  const sh = sheet_(), values = sh.getDataRange().getValues();
  for (let r = 1; r < values.length; r++) {
    if (String(values[r][0]) === id) {
      const status = String(values[r][1] || '').toLowerCase();
      sh.getRange(r + 1, 4).setValue(new Date());
      return json_({authorized: status === 'autorizado' || status === 'authorized'});
    }
  }
  sh.appendRow([id, 'Pendiente', new Date(), new Date(), '', 'Añadir modelo desde notificación si corresponde']);
  return json_({authorized:false, status:'Pendiente'});
}
function doPost(e) {
  let data = {};
  try { data = JSON.parse(e.postData.contents || '{}'); } catch (_) { return json_({ok:false,error:'invalid_json'}); }
  const id = String(data.id || '').trim();
  if (!id) return json_({ok:false,error:'missing_id'});
  const sh = sheet_(), values = sh.getDataRange().getValues();
  for (let r = 1; r < values.length; r++) {
    if (String(values[r][0]) === id) {
      sh.getRange(r + 1, 4).setValue(data.timestamp || new Date());
      if (data.model) sh.getRange(r + 1, 5).setValue(String(data.model));
      return json_({ok:true,existing:true});
    }
  }
  sh.appendRow([id, 'Pendiente', data.timestamp || new Date(), data.timestamp || new Date(), String(data.model || ''), 'Instalación detectada']);
  return json_({ok:true,created:true});
}
