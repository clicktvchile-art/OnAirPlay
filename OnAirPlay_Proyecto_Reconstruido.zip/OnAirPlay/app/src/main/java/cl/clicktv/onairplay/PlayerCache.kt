package cl.clicktv.onairplay

import android.content.Context
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import java.io.File

object PlayerCache {
    @Volatile private var instance: SimpleCache? = null
    fun get(context: Context): SimpleCache = instance ?: synchronized(this) {
        instance ?: SimpleCache(File(context.cacheDir, "stream_cache"), LeastRecentlyUsedCacheEvictor(40L * 1024L * 1024L), StandaloneDatabaseProvider(context)).also { instance = it }
    }
    fun release() { synchronized(this) { try { instance?.release() } catch (_: Exception) {}; instance = null } }
}
