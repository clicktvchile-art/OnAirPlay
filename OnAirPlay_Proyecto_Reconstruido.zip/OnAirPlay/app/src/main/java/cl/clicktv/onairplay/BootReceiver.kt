package cl.clicktv.onairplay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != "android.intent.action.QUICKBOOT_POWERON" && action != "com.htc.intent.action.QUICKBOOT_POWERON") return
        val prefs = context.getSharedPreferences("onairplay_settings", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("autostart", false)) return
        val launch = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        try {
            context.startActivity(launch)
        } catch (e: Exception) {
            // Algunos Android bloquean el inicio de actividades desde segundo plano.
            Log.w("OnAirPlay-Boot", "Android/fabricante bloqueó el inicio automático; revisa el permiso de autoarranque", e)
        }
    }
}
