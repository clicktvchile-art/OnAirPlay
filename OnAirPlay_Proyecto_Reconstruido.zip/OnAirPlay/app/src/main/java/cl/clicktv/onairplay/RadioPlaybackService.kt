package cl.clicktv.onairplay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

class RadioPlaybackService : Service() {
    private var player: ExoPlayer? = null
    private var currentUrl: String = ""
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("onairplay_radio", "OnAirPlay Radio", NotificationManager.IMPORTANCE_LOW))
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { player?.release(); player = null; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            else -> {
                val url = intent?.getStringExtra(EXTRA_URL).orEmpty()
                if (url.isBlank()) { stopSelf(); return START_NOT_STICKY }
                currentUrl = url
                startForeground(1001, notification())
                startPlayer(url)
            }
        }
        return START_STICKY
    }
    private fun startPlayer(url: String) {
        player?.release()
        player = ExoPlayer.Builder(this).setLoadControl(MainActivity.liveLoadControl()).build().apply {
            setMediaItem(MediaItem.fromUri(url)); playWhenReady = true; prepare()
            addListener(object : Player.Listener { override fun onPlayerError(error: androidx.media3.common.PlaybackException) { retry(url) } })
        }
    }
    private fun retry(url: String) {
        android.os.Handler(mainLooper).postDelayed({ startPlayer(url) }, 3000)
    }
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW && currentUrl.isNotBlank()) {
            player?.release(); player = null
            android.os.Handler(mainLooper).postDelayed({ if (currentUrl.isNotBlank()) startPlayer(currentUrl) }, 1500)
        }
    }
    override fun onLowMemory() {
        super.onLowMemory()
        if (currentUrl.isNotBlank()) { player?.release(); player = null; android.os.Handler(mainLooper).postDelayed({ startPlayer(currentUrl) }, 1500) }
    }
    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, RadioPlaybackService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "onairplay_radio").setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("OnAirPlay Radio").setContentText("Reproducción de radio activa").setContentIntent(open).setOngoing(true).addAction(android.R.drawable.ic_media_pause, "Detener", stop).build()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
    companion object { const val ACTION_STOP = "cl.clicktv.onairplay.STOP_RADIO"; const val EXTRA_URL = "radio_url" }
}
