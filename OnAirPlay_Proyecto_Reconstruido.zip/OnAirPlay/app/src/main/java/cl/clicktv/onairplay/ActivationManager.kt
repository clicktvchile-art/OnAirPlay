package cl.clicktv.onairplay

import android.content.Context
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object ActivationManager {
    private const val PREFS = "onairplay_activation"
    private const val KEY_ID = "device_id"
    private const val KEY_AUTH_AT = "authorized_at"
    private const val GRACE_MS = 72L * 60L * 60L * 1000L

    fun deviceId(context: Context): String {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        p.getString(KEY_ID, null)?.let { return it }
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        val id = if (!androidId.isNullOrBlank()) androidId else UUID.randomUUID().toString()
        p.edit().putString(KEY_ID, id).apply()
        return id
    }

    fun isWithinOfflineGrace(context: Context): Boolean {
        val at = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_AUTH_AT, 0L)
        return at > 0L && System.currentTimeMillis() - at <= GRACE_MS
    }

    fun check(context: Context, callback: (Boolean, String) -> Unit) {
        Thread {
            val id = deviceId(context)
            val endpoint = BuildConfig.API_CHECK_URL
            try {
                require(endpoint.startsWith("https://") && !endpoint.contains("REPLACE_WITH")) { "API_CHECK_URL no está configurada" }
                val conn = (URL(endpoint + (if (endpoint.contains("?")) "&" else "?") + "action=check&id=" + id).openConnection() as HttpURLConnection)
                conn.connectTimeout = 7000; conn.readTimeout = 7000; conn.requestMethod = "GET"
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val allowed = JSONObject(body).optBoolean("authorized", false)
                if (allowed) context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_AUTH_AT, System.currentTimeMillis()).apply()
                callback(allowed, if (allowed) "Autorizado" else "Dispositivo pendiente de activación")
            } catch (e: Exception) {
                val grace = isWithinOfflineGrace(context)
                callback(grace, if (grace) "Autorización temporal sin conexión" else "No fue posible validar el dispositivo. Comprueba internet o la configuración del servidor.")
            }
        }.start()
    }

    fun notifyInstall(context: Context) {
        Thread {
            try {
                val endpoint = BuildConfig.API_NOTIFY_URL
                if (!endpoint.startsWith("https://") || endpoint.contains("REPLACE_WITH")) return@Thread
                val model = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL
                val time = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date())
                val json = JSONObject().put("action", "notify").put("id", deviceId(context)).put("timestamp", time).put("model", model)
                val conn = URL(endpoint).openConnection() as HttpURLConnection
                conn.connectTimeout = 7000; conn.readTimeout = 7000; conn.requestMethod = "POST"; conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.outputStream.use { it.write(json.toString().toByteArray(Charsets.UTF_8)) }
                conn.inputStream.close(); conn.disconnect()
            } catch (_: Exception) { /* best-effort notification */ }
        }.start()
    }
}
