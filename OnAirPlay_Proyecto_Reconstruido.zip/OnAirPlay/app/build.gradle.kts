import java.util.Properties
plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
val apiCheckUrl = (project.findProperty("API_CHECK_URL") as String?) ?: "https://script.google.com/macros/s/AKfycbzyOLJ6F1kytvtVvTuvL3GjLwWPidcKIfUIqf8myioeg2_XMc15IOwVKyCZ7ryu_NK9_A/exec"
val apiNotifyUrl = (project.findProperty("API_NOTIFY_URL") as String?) ?: apiCheckUrl
android {
    namespace = "cl.clicktv.onairplay"
    compileSdk = 35
    defaultConfig {
        applicationId = "cl.clicktv.onairplay"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        buildConfigField("String", "API_CHECK_URL", "\"${apiCheckUrl}\"")
        buildConfigField("String", "API_NOTIFY_URL", "\"${apiNotifyUrl}\"")
        buildConfigField("String", "DEFAULT_TV_URL", "\"https://andromeda2.cd-latam.com:1936/Monitoreo_ClickTV/clicktv.stream/playlist.m3u8\"")
        buildConfigField("String", "DEFAULT_RADIO_URL", "\"\"")
    }
    buildFeatures { buildConfig = true }
    buildTypes { release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    // LibVLC provides native SRT transport support (Caller and Listener).
    implementation("org.videolan.android:libvlc-all:3.6.1")
}
// Copy generated APK to a predictable name after successful assemble tasks.
tasks.register<Copy>("copyDebugApk") {
    dependsOn("assembleDebug")
    from(layout.buildDirectory.file("outputs/apk/debug/app-debug.apk"))
    into(layout.buildDirectory.dir("outputs/apk/debug"))
    rename { "OnAirPlay.apk" }
}
tasks.register<Copy>("copyReleaseApk") {
    dependsOn("assembleRelease")
    from(layout.buildDirectory.file("outputs/apk/release/app-release-unsigned.apk"))
    into(layout.buildDirectory.dir("outputs/apk/release"))
    rename { "OnAirPlay.apk" }
}
