package cl.clicktv.onairplay

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("onairplay_settings", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var message: TextView
    private var player: ExoPlayer? = null
    private var retryCount = 0
    private var retryTask: Runnable? = null
    private var lastMode = "tv"
    private var hasNotifiedInstall = false
    private var libVlc: LibVLC? = null
    private var srtPlayer: MediaPlayer? = null
    private var srtVideoLayout: VLCVideoLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)
        if (prefs.getBoolean("first_run", true)) {
            prefs.edit().putBoolean("first_run", false).apply()
            ActivationManager.notifyInstall(this)
        }
        showActivationCheck()
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    private fun showActivationCheck() {
        root.removeAllViews()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 28, 28, 28) }
        box.addView(TextView(this).apply { text = "OnAirPlay"; textSize = 32f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        box.addView(TextView(this).apply { text = "Comprobando activación del dispositivo…"; textSize = 18f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 18, 0, 18) })
        root.addView(box, FrameLayout.LayoutParams(-1, -1))
        ActivationManager.check(this) { allowed, status -> runOnUiThread {
            if (allowed) startMainPlayback() else showBlockedScreen(status)
        } }
    }

    private fun showBlockedScreen(status: String) {
        root.removeAllViews()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 28, 28, 28) }
        box.addView(TextView(this).apply { text = "OnAirPlay"; textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        box.addView(TextView(this).apply { text = "Dispositivo pendiente de activación"; textSize = 21f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 20, 0, 8) })
        box.addView(TextView(this).apply { text = status; textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 0, 0, 18) })
        val id = ActivationManager.deviceId(this)
        box.addView(TextView(this).apply { text = "Código del dispositivo:\n$id"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 10, 0, 14) })
        box.addView(Button(this).apply { text = "Copiar código"; setOnClickListener {
            val clip = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clip.setPrimaryClip(android.content.ClipData.newPlainText("OnAirPlay device ID", id)); Toast.makeText(this@MainActivity, "Código copiado", Toast.LENGTH_SHORT).show()
        } })
        box.addView(Button(this).apply { text = "Comprobar activación"; setOnClickListener { showActivationCheck() } })
        root.addView(box, FrameLayout.LayoutParams(-1, -1))
    }

    private fun startMainPlayback() {
        root.removeAllViews()
        playerView = PlayerView(this).apply { useController = false; setShutterBackgroundColor(Color.BLACK); setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER) }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        message = TextView(this).apply { text = "PRONTO VOLVEMOS\nEstamos experimentando un problema con la señal de origen."; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(0xCC000000.toInt()); visibility = View.GONE; setPadding(24, 24, 24, 24) }
        root.addView(message, FrameLayout.LayoutParams(-1, -1))
        val mode = prefs.getString("last_mode", "tv") ?: "tv"
        when (mode) { "radio" -> startRadioMode(); "srt" -> playSrt(); else -> playTv() }
        root.setOnLongClickListener { showAdminPin(); true }
    }

    private fun makePlayer(): ExoPlayer {
        val upstream = DefaultDataSource.Factory(this)
        val cacheFactory = CacheDataSource.Factory().setCache(PlayerCache.get(this)).setUpstreamDataSourceFactory(upstream).setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        return ExoPlayer.Builder(this).setLoadControl(lowMemoryLoadControl()).setMediaSourceFactory(DefaultMediaSourceFactory(cacheFactory)).build()
    }

    private fun playTv() {
        releaseSrtPlayer()
        playerView.visibility = View.VISIBLE
        lastMode = "tv"; prefs.edit().putString("last_mode", "tv").apply()
        stopRadioService()
        message.visibility = View.GONE
        player?.release()
        player = makePlayer().also { exo ->
            playerView.player = exo
            exo.addListener(object : Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) { scheduleRetry() }
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY && exo.playWhenReady) { retryCount = 0; retryTask?.let(handler::removeCallbacks); message.visibility = View.GONE }
                    if (playbackState == Player.STATE_IDLE || playbackState == Player.STATE_BUFFERING) showMessageDelayed()
                }
            })
            val url = prefs.getString("tv_url", BuildConfig.DEFAULT_TV_URL).orEmpty()
            exo.setMediaItem(MediaItem.fromUri(url)); exo.playWhenReady = true; exo.prepare()
        }
    }

    private fun startRadioMode() {
        releaseSrtPlayer()
        playerView.visibility = View.GONE
        lastMode = "radio"; prefs.edit().putString("last_mode", "radio").apply()
        playerView.player = null; player?.release(); player = null
        val url = prefs.getString("radio_url", BuildConfig.DEFAULT_RADIO_URL).orEmpty()
        if (url.isBlank()) { showAdminPin("Configura la URL de radio para comenzar."); return }
        message.visibility = View.GONE
        val intent = Intent(this, RadioPlaybackService::class.java).putExtra(RadioPlaybackService.EXTRA_URL, url)
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent) }
        catch (_: Exception) { Toast.makeText(this, "No se pudo iniciar la radio en segundo plano", Toast.LENGTH_LONG).show() }
        // A simple full-screen mode indicator; hold Back to open admin settings.
        root.setOnClickListener { Toast.makeText(this, "Radio activa. Mantén pulsada la pantalla para configuración.", Toast.LENGTH_SHORT).show() }
        root.setOnLongClickListener { showAdminPin(); true }
        message.text = "OnAirPlay Radio\nReproducción de audio activa"; message.visibility = View.VISIBLE
    }

    /** Reproduce SRT entrante usando libVLC (SRT no está soportado nativamente por Media3). */
    private fun playSrt() {
        stopRadioService()
        player?.release(); player = null
        playerView.player = null
        playerView.visibility = View.GONE
        lastMode = "srt"
        prefs.edit().putString("last_mode", "srt").apply()
        message.visibility = View.GONE
        val configured = prefs.getString("srt_endpoint", "").orEmpty().trim()
        if (configured.isBlank()) {
            showAdminPin("Configura el host:puerto o URL SRT para comenzar.")
            return
        }
        val mode = prefs.getString("srt_mode", "caller") ?: "caller"
        val uri = normalizeSrtUri(configured, mode)
        try {
            releaseSrtPlayer()
            val args = arrayListOf("--no-video-title-show", "--network-caching=500", "--live-caching=500")
            libVlc = LibVLC(this, args)
            srtPlayer = MediaPlayer(libVlc)
            srtVideoLayout = VLCVideoLayout(this)
            root.removeView(message)
            root.addView(srtVideoLayout, 0, FrameLayout.LayoutParams(-1, -1))
            root.addView(message, FrameLayout.LayoutParams(-1, -1))
            srtPlayer?.attachViews(srtVideoLayout!!, null, false, false)
            val media = Media(libVlc, android.net.Uri.parse(uri))
            media.setHWDecoderEnabled(true, false)
            media.addOption(":network-caching=500")
            srtPlayer?.media = media
            media.release()
            srtPlayer?.play()
            Toast.makeText(this, "Conectando por SRT ($mode)", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            message.text = "No se pudo iniciar SRT\nRevisa la dirección, el puerto y el modo de conexión."
            message.visibility = View.VISIBLE
            Toast.makeText(this, "Error al iniciar SRT: ${e.message ?: "desconocido"}", Toast.LENGTH_LONG).show()
        }
        root.setOnLongClickListener { showAdminPin(); true }
    }

    private fun normalizeSrtUri(input: String, mode: String): String {
        val clean = if (input.startsWith("srt://", ignoreCase = true)) input else "srt://$input"
        val base = clean.substringBefore("?")
        val query = clean.substringAfter("?", "").split("&").filter { it.isNotBlank() && !it.startsWith("mode=") }
        val params = query.toMutableList()
        params.add("mode=$mode")
        if (params.none { it.startsWith("latency=") }) params.add("latency=120")
        // Listener escucha en todas las interfaces del dispositivo en el puerto indicado.
        val port = Regex("(?:srt://)?(?:\\[[^]]+\\]|[^:]+)?:(\\d+)$", RegexOption.IGNORE_CASE).find(base)?.groupValues?.getOrNull(1)
            ?: Regex("^srt://(\\d+)$", RegexOption.IGNORE_CASE).find(base)?.groupValues?.getOrNull(1)
        val endpoint = if (mode == "listener" && port != null) "srt://:$port" else base
        return endpoint + "?" + params.joinToString("&")
    }

    private fun releaseSrtPlayer() {
        try { srtPlayer?.stop() } catch (_: Exception) {}
        try { srtPlayer?.detachViews() } catch (_: Exception) {}
        try { srtPlayer?.release() } catch (_: Exception) {}
        srtPlayer = null
        try { srtVideoLayout?.let { root.removeView(it) } } catch (_: Exception) {}
        srtVideoLayout = null
        try { libVlc?.release() } catch (_: Exception) {}
        libVlc = null
    }

    private fun stopRadioService() { try { stopService(Intent(this, RadioPlaybackService::class.java)) } catch (_: Exception) {} }
    private fun showMessageDelayed() {
        handler.postDelayed({ if (lastMode == "tv" && (player?.playbackState != Player.STATE_READY)) message.visibility = View.VISIBLE }, 5000)
    }
    private fun scheduleRetry() {
        retryTask?.let(handler::removeCallbacks)
        val delay = minOf(30_000L, 2_000L * (1L shl retryCount.coerceAtMost(4))); retryCount++
        showMessageDelayed()
        retryTask = Runnable { if (lastMode == "tv") { player?.let { p -> try { p.stop(); p.setMediaItem(MediaItem.fromUri(prefs.getString("tv_url", BuildConfig.DEFAULT_TV_URL).orEmpty())); p.prepare(); p.playWhenReady = true } catch (_: Exception) { scheduleRetry() } } } }
        handler.postDelayed(retryTask!!, delay)
    }

    private fun showAdminPin(messageText: String? = null) {
        val pinInput = EditText(this).apply { hint = "PIN de administración"; inputType = 2 }
        AlertDialog.Builder(this).setTitle("OnAirPlay · Administración").setMessage(messageText ?: "Introduce el PIN para configurar la aplicación.").setView(pinInput)
            .setPositiveButton("Continuar") { _, _ ->
                val expected = prefs.getString("admin_pin", "1234") ?: "1234"
                if (pinInput.text.toString() == expected) showSettings() else Toast.makeText(this, "PIN incorrecto", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun showSettings() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 10, 22, 0) }
        fun field(label: String, value: String): EditText { panel.addView(TextView(this).apply { text = label }); return EditText(this).also { it.setText(value); panel.addView(it) } }
        val tv = field("URL de TV (HLS/M3U8)", prefs.getString("tv_url", BuildConfig.DEFAULT_TV_URL).orEmpty())
        val radio = field("URL de radio (MP3/AAC/HLS)", prefs.getString("radio_url", BuildConfig.DEFAULT_RADIO_URL).orEmpty())
        val srt = field("SRT: host:puerto o URL srt://…", prefs.getString("srt_endpoint", "").orEmpty())
        panel.addView(TextView(this).apply { text = "Modo SRT actual: ${prefs.getString("srt_mode", "caller")}"; setTextColor(Color.DKGRAY) })
        val pin = field("Nuevo PIN (por defecto 1234)", prefs.getString("admin_pin", "1234").orEmpty())
        val auto = android.widget.CheckBox(this).apply { text = "Intentar inicio automático tras reinicio"; isChecked = prefs.getBoolean("autostart", false) }; panel.addView(auto)
        fun saveAll() { saveSettings(tv.text.toString(), radio.text.toString(), pin.text.toString(), auto.isChecked); prefs.edit().putString("srt_endpoint", srt.text.toString().trim()).apply() }
        AlertDialog.Builder(this).setTitle("Configuración OnAirPlay").setView(panel)
            .setNeutralButton("Modo TV") { _, _ -> saveAll(); playTv() }
            .setNegativeButton("Modo Radio") { _, _ -> saveAll(); startRadioMode() }
            .setPositiveButton("Más opciones") { _, _ -> saveAll(); showSrtOptions() }.show()
    }

    private fun showSrtOptions() {
        val modes = arrayOf("SRT Caller (conectarse al emisor)", "SRT Listener (esperar conexión entrante)")
        AlertDialog.Builder(this).setTitle("OnAirPlay · SRT")
            .setItems(modes) { _, which ->
                val mode = if (which == 0) "caller" else "listener"
                prefs.edit().putString("srt_mode", mode).putString("last_mode", "srt").apply()
                playSrt()
            }
            .setNeutralButton("Volver a configuración") { _, _ -> showAdminPin() }
            .setNegativeButton("Cancelar", null).show()
    }
    private fun saveSettings(tv: String, radio: String, pin: String, auto: Boolean) {
        prefs.edit().putString("tv_url", tv.trim()).putString("radio_url", radio.trim()).putString("admin_pin", pin.ifBlank { "1234" }).putBoolean("autostart", auto).apply()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_INFO) { showAdminPin(); return true }
        if (keyCode == KeyEvent.KEYCODE_BACK && (lastMode == "radio" || lastMode == "srt")) { showAdminPin(); return true }
        return super.onKeyDown(keyCode, event)
    }
    override fun onTrimMemory(level: Int) { super.onTrimMemory(level); if (level >= TRIM_MEMORY_RUNNING_LOW && lastMode == "tv") { try { player?.stop() } catch (_: Exception) {}; scheduleRetry() } }
    override fun onLowMemory() { super.onLowMemory(); if (lastMode == "tv") { try { player?.stop() } catch (_: Exception) {}; scheduleRetry() } }
    override fun onDestroy() { retryTask?.let(handler::removeCallbacks); playerViewOrNullRelease(); PlayerCache.release(); super.onDestroy() }
    private fun playerViewOrNullRelease() { releaseSrtPlayer(); try { playerView.player = null } catch (_: Exception) {}; player?.release(); player = null }

    companion object {
        fun lowMemoryLoadControl(): DefaultLoadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(1500, 10000, 500, 1000)
            .setPrioritizeTimeOverSizeThresholds(true)
            .setTargetBufferBytes(8 * 1024 * 1024)
            .build()
    }
}
