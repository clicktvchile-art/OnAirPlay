package cl.clicktv.onairplay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("onairplay_settings", Context.MODE_PRIVATE)
        if (prefs.getBoolean("autostart", false)) {
            val launch = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { context.startActivity(launch) } catch (_: Exception) { /* Android/OEM may block background activity launches. */ }
        }
    }
}
