# OnAirPlay — proyecto Android

Proyecto base Kotlin/Android para reproducción de TV HLS/M3U8, entrada de vídeo en vivo SRT (Caller y Listener) y radio HTTP/HTTPS MP3/AAC/HLS, con control de activación online mediante Google Apps Script + Google Sheets.

> Estado: código fuente inicial. No se incluye un APK precompilado ni se afirma que se haya ejecutado una compilación o prueba de dispositivo. Compilar y probar antes de uso de emisión.

## Requisitos
- Android Studio reciente o GitHub Actions.
- JDK 17.
- Android SDK 35.
- Conexión a Internet para resolver dependencias.

## Configurar SRT
1. Abre la app y mantén pulsada la pantalla para abrir Administración (PIN inicial `1234`).
2. En `SRT: host:puerto o URL srt://…`, para Caller escribe la dirección del emisor, por ejemplo `srt://192.0.2.10:9000`. Para Listener escribe el puerto de escucha, por ejemplo `9000` o `srt://0.0.0.0:9000`.
3. Pulsa `Más opciones` y elige Caller o Listener. La app inicia la recepción SRT.
4. Para Listener, el emisor remoto debe conectarse a la IP del dispositivo Android/TV y al puerto UDP elegido; revisa el firewall y la red. No todos los proveedores SRT usan los mismos parámetros de latencia, cifrado o stream ID.

## URL predeterminada
La fuente TV predeterminada está en `app/build.gradle.kts` y corresponde al enlace M3U8 entregado para ClickTv. La URL de radio se deja vacía para que el administrador la configure.

## Configurar API de activación
1. Crea una hoja de Google Sheets vacía y copia su ID desde la URL.
2. Abre `backend-gas/Code.gs`, reemplaza `REPLACE_WITH_GOOGLE_SHEET_ID` por el ID.
3. En Apps Script, ejecuta `doGet` no es necesario manualmente; acepta permisos cuando se soliciten.
4. Implementa > Nueva implementación > Aplicación web. Ejecutar como: tú. El acceso debe permitir que la app consulte el endpoint (la disponibilidad de “cualquiera” depende de las políticas de tu cuenta/organización).
5. Copia la URL `/exec` desplegada.
6. En GitHub, abre Settings > Secrets and variables > Actions > Variables y crea `API_CHECK_URL` con esa URL. Crea `API_NOTIFY_URL` con la misma URL (o una URL separada).
7. El workflow de GitHub Actions inyecta ambas variables durante la compilación. También puedes compilar localmente pasando `-PAPI_CHECK_URL=https://.../exec -PAPI_NOTIFY_URL=https://.../exec`.
8. Instala la app en un dispositivo conectado a Internet. La primera consulta crea un registro `Pendiente` en la hoja. Cambia manualmente la columna `status` a `Autorizado` y pulsa “Comprobar activación” en la app.

**Seguridad:** el ejemplo es una base sencilla y no está endurecido para distribución comercial. Un endpoint público puede ser abusado; añade autenticación, límites de uso, controles administrativos y protección de la hoja antes de usarlo en producción. Un ID de dispositivo no es un mecanismo imposible de falsificar. La validación en cliente también puede modificarse en dispositivos comprometidos.

## Compilar en GitHub desde el celular
1. Crea un repositorio en GitHub y sube todos los archivos de esta carpeta conservando su estructura.
2. En Settings > Secrets and variables > Actions > Variables, configura `API_CHECK_URL` y `API_NOTIFY_URL` antes de compilar.
3. Abre la pestaña Actions y ejecuta el workflow **Build Android APK** (o haz push a `main`).
4. Espera que termine correctamente. Descarga el artefacto `OnAirPlay-apk` desde el resultado del workflow.
5. El APK de depuración se puede instalar para pruebas; Android puede pedir permitir instalaciones desde el navegador/archivos.

## Compilar con Gradle
```bash
./gradlew assembleDebug -PAPI_CHECK_URL=https://script.google.com/macros/s/DEPLOYMENT_ID/exec -PAPI_NOTIFY_URL=https://script.google.com/macros/s/DEPLOYMENT_ID/exec
./gradlew copyDebugApk
```
Salida habitual: `app/build/outputs/apk/debug/OnAirPlay.apk`.

## Logo manual
No se adjuntó un archivo de logo en esta solicitud, así que los iconos son placeholders neutros. Para sustituirlos:
1. Prepara un PNG cuadrado de tu logo, idealmente 1024×1024, con el fondo que desees.
2. Genera los iconos con Android Studio > New > Image Asset > Launcher Icons (Adaptive and Legacy), o usa una herramienta fiable de generación de iconos.
3. Sustituye `ic_launcher.png` y `ic_launcher_round.png` en cada carpeta `app/src/main/res/mipmap-mdpi`, `mipmap-hdpi`, `mipmap-xhdpi`, `mipmap-xxhdpi` y `mipmap-xxxhdpi`.
4. Usa PNG con transparencia cuando corresponda y comprueba el recorte circular. Mantén esos nombres exactos.
5. Vuelve a compilar el proyecto.

## Funcionalidad y límites conocidos
- HLS/M3U8 de TV se reproduce con Media3 ExoPlayer.
- SRT entrante usa LibVLC 3.6.1; en Administración > Más opciones se puede seleccionar Caller (conectar a `srt://HOST:PUERTO`) o Listener (escuchar en el puerto indicado, por ejemplo `9000` o `srt://HOST:9000`). En Listener, la app intenta escuchar en todas las interfaces del dispositivo. El firewall/router debe permitir el tráfico SRT/UDP y el emisor debe usar el mismo puerto y parámetros compatibles. La recepción SRT requiere pruebas reales con el equipo emisor y no usa la caché Media3.
- LibVLC agrega una dependencia nativa grande y tiene implicaciones de licencia LGPL/GPL que deben revisarse antes de distribuir comercialmente la app; consulta los términos de VideoLAN y cumple las obligaciones de distribución aplicables.
- Radio MP3/AAC/HLS usa un servicio en primer plano con notificación; prueba en Android 13+ los permisos y políticas de notificaciones/servicios del fabricante.
- El selector de radio utiliza la URL introducida en administración. Si está vacía, solicita configurarla.
- Caché de disco LRU de 40 MiB configurada para fuentes reproducibles por Media3. Los streams de radio del servicio no usan esa caché compartida.
- El búfer del reproductor se limita mediante `DefaultLoadControl`; los códecs y el consumo final dependen del dispositivo y del stream.
- Si el endpoint no está configurado o no se puede validar y no existe autorización previa dentro de la ventana offline de 72 horas, el reproductor permanece bloqueado.
- La notificación de instalación es de mejor esfuerzo; un error de red no impide consultar la activación.
- El autoarranque puede ser bloqueado por Android o por el fabricante. En esos equipos configura OnAirPlay como launcher predeterminado si está disponible.
- `onTrimMemory` / `onLowMemory` detienen el reproductor de TV ante presión de memoria; valida el comportamiento real antes de producción.
